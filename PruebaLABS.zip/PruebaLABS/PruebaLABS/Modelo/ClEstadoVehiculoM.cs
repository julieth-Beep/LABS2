﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaLABS.Modelo
{
    public class ClEstadoVehiculoM
    {
        public int estadoVehiculo { get; set; }
        public string descripcionEstadoVehiculo { get; set; }
    }
}