﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaLABS.Modelo
{
    public class ClRolM
    {
        public  int idRol { get; set; }
        public string nombreRol { get; set; }
        public string Descripcion { get; set; }
    }
}